import os
import json
import boto3
from botocore.exceptions import ClientError

REGION = os.environ.get("AWS_REGION", "eu-central-1")
SES_SENDER = os.environ.get("SES_SENDER")       # remitente verificado en SES
SES_RECIPIENT = os.environ.get("SES_RECIPIENT") # destinatario (verificado si tu SES está en sandbox)
PUBLIC_DOMAIN = os.environ.get("CLOUDFRONT_DOMAIN", "")  # tu S3 website host o CloudFront domain

ses = boto3.client("ses", region_name=REGION)

def _safe_json_loads(s: str):
    try:
        return json.loads(s)
    except Exception:
        return {"raw": s}

def _extract_payload(event):
    """
    Soporta:
    - Disparo por SNS: event['Records'][0]['Sns']['Message'] (string JSON)
    - Disparo directo de prueba (aws lambda invoke) con JSON simple
    Retorna un dict con 'type' y 'product'
    """
    if isinstance(event, dict) and "Records" in event:
        # Evento SNS
        rec = event["Records"][0]
        msg_str = rec.get("Sns", {}).get("Message", "{}")
        payload = _safe_json_loads(msg_str)
    else:
        payload = event

    # Normaliza
    if not isinstance(payload, dict):
        payload = {"type": "UNKNOWN", "product": {}}
    payload.setdefault("type", "NEW_PRODUCT")
    payload.setdefault("product", {})

    return payload

def _build_email(product: dict):
    name = product.get("product_name", "New product")
    sku = product.get("sku", "")
    price = product.get("price", "")
    image_key = product.get("image_key", "")

    img_url = ""
    if PUBLIC_DOMAIN and image_key:
        # Nota: es http para S3 website endpoint; si usas CloudFront será https
        scheme = "https" if PUBLIC_DOMAIN.startswith(("d", "cloudfront",)) else "http"
        img_url = f"{scheme}://{PUBLIC_DOMAIN}/{image_key}"

    subject = f"New product available: {name}"

    text = f"""New product available

Name: {name}
SKU: {sku}
Price: {price}
{"Image: " + img_url if img_url else ""}

"""

    html = f"""<html>
  <body style="font-family: Arial, sans-serif;">
    <h2>New product available</h2>
    <p><strong>Name:</strong> {name}</p>
    <p><strong>SKU:</strong> {sku}</p>
    <p><strong>Price:</strong> {price}</p>
    {f'<p><img src="{img_url}" alt="{name}" style="max-width:400px;border:1px solid #ddd;border-radius:8px;"></p>' if img_url else ''}
  </body>
</html>
"""
    return subject, text, html

def _send_email(subject, text, html):
    if not SES_SENDER or not SES_RECIPIENT:
        raise RuntimeError("SES_SENDER y/o SES_RECIPIENT no están definidos en variables de entorno.")

    return ses.send_email(
        Source=SES_SENDER,
        Destination={"ToAddresses": [SES_RECIPIENT]},
        Message={
            "Subject": {"Data": subject, "Charset": "UTF-8"},
            "Body": {
                "Text": {"Data": text, "Charset": "UTF-8"},
                "Html": {"Data": html, "Charset": "UTF-8"},
            },
        },
    )

def lambda_handler(event, context):
    # Extrae payload normalizado
    payload = _extract_payload(event)
    product = payload.get("product", {})

    # Construye email
    subject, text, html = _build_email(product)

    try:
        resp = _send_email(subject, text, html)
        msg_id = resp["MessageId"]
        return {"statusCode": 200, "body": json.dumps({"ok": True, "ses_message_id": msg_id})}
    except ClientError as e:
        return {"statusCode": 500, "body": json.dumps({"ok": False, "error": str(e)})}
